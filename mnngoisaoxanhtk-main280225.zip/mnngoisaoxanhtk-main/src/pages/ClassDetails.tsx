
import { FC } from "react";
import Header from "../components/Header";
import Navigation from "../components/Navigation";
import ContactSection from "../components/ContactSection";

interface ClassDetailsProps {
  type: "lon" | "nho" | "tre" | "be";
}

const classInfo = {
  lon: {
    name: "Lớp Lớn",
    ageRange: "5-6 tuổi",
    description: "Lớp chuẩn bị cho bé vào lớp 1, tập trung phát triển kỹ năng đọc, viết, toán học cơ bản và các kỹ năng xã hội.",
    activities: [
      "Học chữ cái và số đếm",
      "Phát triển kỹ năng vận động tinh",
      "Rèn luyện kỹ năng xã hội và làm việc nhóm",
      "Chuẩn bị tâm lý sẵn sàng vào lớp 1"
    ],
    image: "/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
  },
  nho: {
    name: "Lớp Nhỡ",
    ageRange: "4-5 tuổi",
    description: "Lớp tập trung vào phát triển ngôn ngữ, kỹ năng vận động và khả năng nghệ thuật của bé.",
    activities: [
      "Học hát và múa",
      "Phát triển kỹ năng ngôn ngữ",
      "Các hoạt động nghệ thuật và thủ công",
      "Tăng cường vận động thô"
    ],
    image: "/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
  },
  tre: {
    name: "Lớp Trẻ",
    ageRange: "3-4 tuổi",
    description: "Lớp giúp bé làm quen với môi trường trường lớp, tập trung vào phát triển vận động và kỹ năng giao tiếp cơ bản.",
    activities: [
      "Học qua vui chơi",
      "Phát triển kỹ năng vận động",
      "Làm quen với màu sắc và hình dạng",
      "Tập thói quen sinh hoạt cá nhân"
    ],
    image: "/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
  },
  be: {
    name: "Lớp Bé",
    ageRange: "2-3 tuổi",
    description: "Lớp đầu tiên của bé tại trường, tập trung vào việc tạo môi trường an toàn và thân thiện để bé làm quen với việc xa gia đình.",
    activities: [
      "Làm quen với môi trường lớp học",
      "Phát triển kỹ năng giao tiếp cơ bản",
      "Học tập thông qua trò chơi",
      "Phát triển tình cảm và kỹ năng xã hội"
    ],
    image: "/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
  }
};

const ClassDetails: FC<ClassDetailsProps> = ({ type }) => {
  const info = classInfo[type];

  return (
    <div className="min-h-screen bg-school-blue/20">
      <Header />
      <Navigation />

      <main className="container mx-auto px-4 md:px-6 py-6 md:py-8 max-w-7xl">
        <div className="bg-white rounded-lg shadow-md p-6 md:p-8 animate-fade-in">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/2">
              <h1 className="text-2xl md:text-3xl font-bold text-red-600 mb-2">{info.name}</h1>
              <p className="text-lg text-blue-600 font-semibold mb-4">Độ tuổi: {info.ageRange}</p>
              <p className="text-gray-700 mb-6">{info.description}</p>
              
              <h2 className="text-xl font-semibold text-green-600 mb-4">Các hoạt động chính:</h2>
              <ul className="space-y-2">
                {info.activities.map((activity, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-2 h-2 rounded-full bg-yellow-400 mt-2 mr-2"></span>
                    <span>{activity}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="md:w-1/2">
              <div className="rounded-lg overflow-hidden shadow-md">
                <img 
                  src={info.image} 
                  alt={info.name} 
                  className="w-full h-auto object-cover"
                />
              </div>
              
              <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <h3 className="text-lg font-semibold text-orange-600 mb-2">Lịch học</h3>
                <p className="text-gray-700">Thời gian học: Từ thứ Hai đến thứ Sáu</p>
                <p className="text-gray-700">Sáng: 7:30 - 11:30</p>
                <p className="text-gray-700">Chiều: 13:30 - 17:00</p>
              </div>
            </div>
          </div>
        </div>
        
        <ContactSection />
      </main>
    </div>
  );
};

export default ClassDetails;
