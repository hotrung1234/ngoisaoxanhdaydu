
import { FC } from "react";
import Header from "../components/Header";
import Navigation from "../components/Navigation";

const Gallery: FC = () => {
  const images = [
    "/lovable-uploads/3a736bc2-764f-4a0f-b6a9-1cfe5fec0950.png",
    "/lovable-uploads/6f117604-8763-4ae6-86d0-91610d3ab8cd.png",
    "/lovable-uploads/55a09ef1-ab7f-4a94-9c36-bb0814ad0829.png",
    "/lovable-uploads/e5dff2bd-5517-4768-a3dd-6f35358cba1e.png",
    "/lovable-uploads/f33e63cb-065f-44c3-8696-0efe43e3ff64.png",
    "/lovable-uploads/59df28b4-d015-4122-a4c9-149633a42384.png",
    "/lovable-uploads/83421ea1-95d8-4a0c-8e76-b597bd9372ea.png",
    "/lovable-uploads/aec7e015-6102-4bae-9056-9b5dd377846e.png",
    "/lovable-uploads/4e65752c-328b-4c71-b62f-ad0c2226b0de.png",
    "/lovable-uploads/a0eb1155-31ec-40d2-b69f-d33f5efb2996.png",
    "/lovable-uploads/1043cb0d-3108-40fe-9f1e-1ecd30d22bd2.png",
    "/lovable-uploads/2e8601c2-49a1-41cd-a66c-e1d290af2dd8.png"
  ];

  return (
    <div className="min-h-screen bg-school-blue/20">
      <Header />
      <Navigation />
      <main className="container mx-auto px-4 md:px-6 py-6 md:py-8">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-6">Thư viện ảnh</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((image, index) => (
            <div key={index} className="aspect-[4/3] rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
              <img 
                src={image} 
                alt={`School event ${index + 1}`}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Gallery;
