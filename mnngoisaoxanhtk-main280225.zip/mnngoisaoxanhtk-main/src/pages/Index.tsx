
import { FC, useState, useEffect } from "react";
import Header from "../components/Header";
import Navigation from "../components/Navigation";
import AnnouncementBox from "../components/AnnouncementBox";
import ContactSection from "../components/ContactSection";
import AdmissionsSection from "../components/AdmissionsSection";

const Index: FC = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const images = [
    "/lovable-uploads/7b485be4-424b-4046-93fd-fcadaddc85e4.png",
    "/lovable-uploads/6f117604-8763-4ae6-86d0-91610d3ab8cd.png",
    "/lovable-uploads/55a09ef1-ab7f-4a94-9c36-bb0814ad0829.png",
    "/lovable-uploads/e5dff2bd-5517-4768-a3dd-6f35358cba1e.png",
    "/lovable-uploads/f33e63cb-065f-44c3-8696-0efe43e3ff64.png"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => 
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, 3000);

    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <div className="min-h-screen bg-school-blue/20">
      <Header />
      <Navigation />

      <main className="container mx-auto px-4 md:px-6 py-6 md:py-8 max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-8">
          <div className="md:col-span-4 order-2 md:order-1">
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6 h-[calc(100vh-12rem)] overflow-y-auto">
              <h3 className="flex items-center gap-2 text-base md:text-lg font-semibold mb-4 md:mb-6 bg-green-100 p-2 rounded">
                <span className="w-3 h-3 bg-yellow-400 rounded-full"></span>
                Thông báo
              </h3>
              <div className="grid gap-4 md:gap-6">
                <AnnouncementBox
                  category="Cho bé yêu"
                  categoryColor="bg-orange-400"
                  title="❤️Hoạt động nghe, đọc thơ : Bài thơ yêu mẹ của lớp Trẻ 2 (13-18 tháng tuổi) ❤️"
                  image="/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
                  content={[
                    "Hưởng ứng tuần lễ Học tập suốt đời năm 2024 với chủ đề \"Phát triển văn hóa đọc\"",
                    "Kế Hoạch Tổ chức và thực hiện sự kiện Vui Tết Trung Thu năm học 2024-2025"
                  ]}
                />
                <AnnouncementBox
                  category="Cho cha mẹ"
                  categoryColor="bg-orange-400"
                  title="📢 Thông Báo về việc đăng ký cấp thẻ Căn cước qua Cổng Dịch vụ công trực tuyến cho trẻ em dưới 6 tuổi tại trường Mầm Non Ngôi Sao Xanh"
                  image="/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
                  content={[
                    "CHÀO MỪNG ĐOÀN GIÁO SINH THỰC TẬP SƯ PHẠM HỆ CHÍNH QUY NĂM 2025",
                    "THỰC ĐƠN TUẦN 3 THÁNG 02-2025"
                  ]}
                />
              </div>
            </div>
          </div>

          <div className="md:col-span-8 order-1 md:order-2">
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
              <div className="w-full aspect-[16/9] overflow-hidden rounded-lg">
                <img 
                  src={images[currentImageIndex]}
                  alt="School Event"
                  className="w-full h-full object-cover transition-opacity duration-500"
                />
              </div>
            </div>
          </div>
        </div>

        <AdmissionsSection />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mt-6 md:mt-8">
          <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
            <h3 className="flex items-center gap-2 text-base md:text-lg font-semibold mb-4 md:mb-6 bg-soft-yellow p-2 rounded">
              <span className="w-3 h-3 bg-school-orange rounded-full"></span>
              Góc bé yêu
            </h3>
            <div className="space-y-4">
              <AnnouncementBox
                category="Hoạt động"
                categoryColor="bg-school-orange"
                title="🌟 Hoạt động vẽ tranh sáng tạo của các bé lớp Mầm"
                image="/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
                content={[
                  "Các bé lớp Mầm tham gia hoạt động vẽ tranh sáng tạo",
                  "Phát triển khả năng nghệ thuật và óc sáng tạo"
                ]}
              />
              <AnnouncementBox
                category="Sinh hoạt"
                categoryColor="bg-school-green"
                title="🎵 Giờ học hát và vận động của lớp Chồi"
                image="/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
                content={[
                  "Hoạt động ca hát và vận động theo nhạc",
                  "Rèn luyện kỹ năng âm nhạc và vận động"
                ]}
              />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
            <h3 className="flex items-center gap-2 text-base md:text-lg font-semibold mb-4 md:mb-6 bg-soft-blue p-2 rounded">
              <span className="w-3 h-3 bg-school-blue rounded-full"></span>
              Góc phụ huynh
            </h3>
            <div className="space-y-4">
              <AnnouncementBox
                category="Dinh dưỡng"
                categoryColor="bg-school-blue"
                title="🍎 Hướng dẫn chế độ dinh dưỡng cho trẻ"
                image="/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
                content={[
                  "Thông tin về chế độ dinh dưỡng khoa học cho trẻ",
                  "Các món ăn bổ dưỡng phù hợp với lứa tuổi"
                ]}
              />
              <AnnouncementBox
                category="Tư vấn"
                categoryColor="bg-school-red"
                title="💡 Kỹ năng dạy trẻ học tập tại nhà"
                image="/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png"
                content={[
                  "Phương pháp hỗ trợ trẻ học tập hiệu quả tại nhà",
                  "Tạo môi trường học tập tích cực cho trẻ"
                ]}
              />
            </div>
          </div>
        </div>

        <ContactSection />
      </main>
    </div>
  );
};

export default Index;
