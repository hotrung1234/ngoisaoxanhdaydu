
import { FC } from "react";
import { Phone, Mail, MapPin, Facebook } from "lucide-react";

const Header: FC = () => {
  return (
    <header 
      className="bg-white py-4 px-4 md:px-6 shadow-md relative"
      style={{
        backgroundImage: "url('/lovable-uploads/9f934b5c-a22d-46d0-b4e2-e0e356773730.png')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        minHeight: "180px"
      }}
    >
      <div className="absolute inset-0 bg-white/60"></div>
      <div className="container mx-auto max-w-7xl relative z-10">
        <div className="flex flex-col md:flex-row items-center gap-4">
          <img 
            src="/lovable-uploads/c6727979-0593-4920-b0e9-73d5e9d2477d.png" 
            alt="Logo" 
            className="w-16 h-16 md:w-20 md:h-20 rounded-full"
          />
          <div className="text-center md:text-left">
            <h1 className="text-red-600 font-bold text-lg md:text-2xl">ỦY BAN NHÂN DÂN QUẬN THANH KHÊ</h1>
            <h2 className="text-blue-600 font-semibold text-base md:text-xl">TRƯỜNG MẦM NON NGÔI SAO XANH</h2>
            <div className="flex flex-col gap-1 mt-2 text-gray-600 text-sm md:text-base">
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <Phone size={16} />
                <span>0236727466</span>
              </div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <Mail size={16} />
                <span>ngoisaoxanh114@gmail.com</span>
              </div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <MapPin size={16} />
                <span className="break-words">122 Huỳnh Ngọc Huệ, Quận Thanh Khê, Đà Nẵng</span>
              </div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <Facebook size={16} className="text-blue-600" />
                <a 
                  href="https://www.facebook.com/103755418223477?ref=embed_page" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  Fanpage Facebook
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
