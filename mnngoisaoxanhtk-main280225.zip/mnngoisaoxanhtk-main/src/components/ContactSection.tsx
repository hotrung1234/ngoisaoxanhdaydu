
import { FC } from "react";
import { Phone, Mail, MapPin, Facebook, User } from "lucide-react";

const ContactSection: FC = () => {
  return (
    <div className="mt-8 bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold text-blue-600 mb-6">Thông Tin Liên Hệ</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Phone className="text-blue-600" size={20} />
            <div>
              <p className="font-medium">Số điện thoại</p>
              <p>0236727466</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Mail className="text-blue-600" size={20} />
            <div>
              <p className="font-medium">Email</p>
              <p>ngoisaoxanh114@gmail.com</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <MapPin className="text-blue-600" size={20} />
            <div>
              <p className="font-medium">Địa chỉ</p>
              <p>122 Huỳnh Ngọc Huệ, Quận Thanh Khê, Đà Nẵng</p>
            </div>
          </div>
        </div>
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <User className="text-blue-600" size={20} />
            <div>
              <p className="font-medium">Ban Giám Hiệu</p>
              <div className="mt-2 space-y-2">
                <p><span className="font-medium">Hiệu trưởng:</span> Nguyễn Thị Ánh Tuyết</p>
                <p><span className="font-medium">Hiệu phó:</span> Lê Thị Tiên Thu Tâm</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Facebook className="text-blue-600" size={20} />
            <div>
              <p className="font-medium">Mạng xã hội</p>
              <a 
                href="https://www.facebook.com/103755418223477?ref=embed_page"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                Fanpage Facebook
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactSection;
