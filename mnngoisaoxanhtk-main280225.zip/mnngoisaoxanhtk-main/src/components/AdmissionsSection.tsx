
import { FC } from "react";

const AdmissionsSection: FC = () => {
  return (
    <div className="bg-gradient-to-b from-yellow-50 to-green-50 rounded-lg shadow-md p-4 md:p-6 mt-6 md:mt-8" data-section="admissions" id="admissions">
      <h2 className="text-xl md:text-2xl font-bold text-blue-600 mb-4 flex items-center">
        <span className="w-3 h-3 bg-blue-500 rounded-full mr-2"></span>
        Tuyển sinh
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <div className="space-y-4">
          <p className="font-semibold text-green-700">
            Trường Mầm Non Ngôi Sao Xanh tuyển sinh trẻ em từ 18 tháng tuổi đến 6 tuổi.
          </p>
          
          <p>
            Đây là độ tuổi vàng trong sự phát triển của trẻ, là giai đoạn trẻ bắt đầu hình thành những 
            kỹ năng và kiến thức cơ bản, là nền tảng cho sự phát triển sau này.
          </p>
          
          <p>
            Trẻ từ 18 tháng tuổi đến 6 tuổi đang trong giai đoạn phát triển thể chất và trí tuệ nhanh chóng. 
            Trẻ học hỏi và khám phá thế giới xung quanh một cách tích cực.
          </p>
          
          <p>
            Trường Mầm Non Ngôi Sao Xanh với đội ngũ giáo viên giàu kinh nghiệm, tận tâm sẽ giúp trẻ 
            phát triển toàn diện cả về thể chất, trí tuệ, tình cảm và thẩm mỹ.
          </p>
        </div>
        
        <div className="flex justify-center">
          <img 
            src="/lovable-uploads/b74c0fa7-cc6f-4443-be16-2117821af0f7.png" 
            alt="Trẻ em tại Trường Mầm Non Ngôi Sao Xanh" 
            className="rounded-lg shadow-md max-w-full h-auto max-h-80 object-contain"
          />
        </div>
      </div>
      
      <div className="mt-6 bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
        <h3 className="text-lg font-semibold text-blue-700 mb-2">Thông tin tuyển sinh:</h3>
        <ul className="list-disc list-inside space-y-2 text-gray-700">
          <li>Độ tuổi: 18 tháng - 6 tuổi</li>
          <li>Thời gian đăng ký: Nhận đăng ký quanh năm</li>
          <li>Liên hệ: 0236727466</li>
          <li>Email: ngoisaoxanh114@gmail.com</li>
        </ul>
      </div>
    </div>
  );
};

export default AdmissionsSection;
