
import { FC } from "react";

interface AnnouncementBoxProps {
  category: string;
  categoryColor: string;
  title: string;
  image?: string;
  content: string[];
}

const AnnouncementBox: FC<AnnouncementBoxProps> = ({ category, categoryColor, title, image, content }) => (
  <div className="border border-yellow-200 rounded-lg p-3 md:p-4 hover:shadow-md transition-shadow">
    <div className="flex items-center gap-2 mb-2 md:mb-3">
      <div className={`${categoryColor} text-white px-3 py-1 rounded-full text-xs md:text-sm font-medium`}>
        {category}
      </div>
    </div>
    <h4 className="text-gray-800 font-medium text-sm md:text-base mb-2 md:mb-3 line-clamp-2">{title}</h4>
    {image && (
      <div className="mb-2 md:mb-3">
        <img src={image} alt={title} className="w-full h-32 md:h-40 object-cover rounded-lg" />
      </div>
    )}
    <div className="space-y-1 md:space-y-2">
      {content.map((item, index) => (
        <p key={index} className="text-gray-600 text-xs md:text-sm line-clamp-2">{item}</p>
      ))}
    </div>
  </div>
);

export default AnnouncementBox;
