
import { FC, useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { ChevronDown, Menu, X } from "lucide-react";

interface NavButtonProps {
  color: string;
  text: string;
  to?: string;
  onClick?: () => void;
  hasSubmenu?: boolean;
  isActive?: boolean;
}

const NavButton: FC<NavButtonProps> = ({ color, text, to, onClick, hasSubmenu = false, isActive = false }) => {
  const className = `${color} text-white px-4 md:px-6 py-2 md:py-3 rounded-full hover:opacity-90 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg font-medium md:font-semibold text-sm md:text-base whitespace-nowrap flex items-center gap-1`;
  
  if (to) {
    return (
      <Link to={to} className={className}>
        {text}
        {hasSubmenu && <ChevronDown size={16} className={`transition-transform duration-300 ${isActive ? 'rotate-180' : ''}`} />}
      </Link>
    );
  }
  
  return (
    <button className={className} onClick={onClick}>
      {text}
      {hasSubmenu && <ChevronDown size={16} className={`transition-transform duration-300 ${isActive ? 'rotate-180' : ''}`} />}
    </button>
  );
};

const Navigation: FC = () => {
  const [showClassSubmenu, setShowClassSubmenu] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const submenuRef = useRef<HTMLDivElement>(null);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  
  const scrollToAdmissions = () => {
    const admissionsSection = document.querySelector('[data-section="admissions"]');
    if (admissionsSection) {
      admissionsSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.location.href = '/#admissions';
    }
  };

  const toggleClassSubmenu = () => {
    setShowClassSubmenu(!showClassSubmenu);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Close submenus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (submenuRef.current && !submenuRef.current.contains(event.target as Node)) {
        setShowClassSubmenu(false);
      }
      
      if (mobileMenuRef.current && !mobileMenuRef.current.contains(event.target as Node) && isMobileMenuOpen) {
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMobileMenuOpen]);

  return (
    <nav className="sticky top-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4 md:px-6 py-4">
        {/* Desktop Navigation */}
        <div className="hidden md:flex md:justify-between items-center gap-4">
          <NavButton color="bg-orange-500" text="Trang chủ" to="/" />
          
          <div className="relative" ref={submenuRef}>
            <NavButton 
              color="bg-red-500" 
              text="Lớp Học Của Bé" 
              onClick={toggleClassSubmenu} 
              hasSubmenu={true}
              isActive={showClassSubmenu}
            />
            
            {showClassSubmenu && (
              <div className="absolute top-full left-0 mt-2 w-44 bg-white rounded-lg shadow-xl z-50 animate-fade-in">
                <div className="p-2 space-y-1">
                  <Link to="/lop-lon" className="block px-4 py-2 text-gray-700 hover:bg-red-500 hover:text-white rounded-md transition-colors">
                    Lớp Lớn
                  </Link>
                  <Link to="/lop-nho" className="block px-4 py-2 text-gray-700 hover:bg-red-500 hover:text-white rounded-md transition-colors">
                    Lớp Nhỡ
                  </Link>
                  <Link to="/lop-tre" className="block px-4 py-2 text-gray-700 hover:bg-red-500 hover:text-white rounded-md transition-colors">
                    Lớp Trẻ
                  </Link>
                  <Link to="/lop-be" className="block px-4 py-2 text-gray-700 hover:bg-red-500 hover:text-white rounded-md transition-colors">
                    Lớp Bé
                  </Link>
                </div>
              </div>
            )}
          </div>
          
          <NavButton color="bg-yellow-500" text="Góc phụ huynh" />
          <NavButton color="bg-blue-500" text="Tuyển sinh" onClick={scrollToAdmissions} />
          <NavButton color="bg-green-500" text="Liên hệ" />
          <NavButton color="bg-cyan-500" text="Thư viện ảnh" to="/gallery" />
        </div>
        
        {/* Mobile Navigation */}
        <div className="flex md:hidden justify-between items-center">
          <Link to="/" className="text-xl font-bold text-orange-500">Trường Mầm Non</Link>
          <button 
            onClick={toggleMobileMenu} 
            className="p-2 rounded-md bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div 
          ref={mobileMenuRef}
          className="md:hidden bg-white shadow-inner py-4 animate-fade-in"
        >
          <div className="container mx-auto px-4 flex flex-col space-y-2">
            <Link to="/" className="bg-orange-500 text-white px-4 py-2 rounded-full hover:opacity-90 text-center">
              Trang chủ
            </Link>
            
            <div className="space-y-2">
              <button 
                onClick={toggleClassSubmenu}
                className="bg-red-500 text-white px-4 py-2 rounded-full hover:opacity-90 w-full flex items-center justify-center gap-1"
              >
                Lớp Học Của Bé
                <ChevronDown size={16} className={`transition-transform duration-300 ${showClassSubmenu ? 'rotate-180' : ''}`} />
              </button>
              
              {showClassSubmenu && (
                <div className="bg-white rounded-lg shadow-inner animate-fade-in ml-4">
                  <div className="p-2 space-y-1">
                    <Link to="/lop-lon" className="block px-4 py-2 text-gray-700 hover:bg-red-500 hover:text-white rounded-md transition-colors">
                      Lớp Lớn
                    </Link>
                    <Link to="/lop-nho" className="block px-4 py-2 text-gray-700 hover:bg-red-500 hover:text-white rounded-md transition-colors">
                      Lớp Nhỡ
                    </Link>
                    <Link to="/lop-tre" className="block px-4 py-2 text-gray-700 hover:bg-red-500 hover:text-white rounded-md transition-colors">
                      Lớp Trẻ
                    </Link>
                    <Link to="/lop-be" className="block px-4 py-2 text-gray-700 hover:bg-red-500 hover:text-white rounded-md transition-colors">
                      Lớp Bé
                    </Link>
                  </div>
                </div>
              )}
            </div>
            
            <button className="bg-yellow-500 text-white px-4 py-2 rounded-full hover:opacity-90 text-center">
              Góc phụ huynh
            </button>
            <button 
              onClick={scrollToAdmissions} 
              className="bg-blue-500 text-white px-4 py-2 rounded-full hover:opacity-90 text-center"
            >
              Tuyển sinh
            </button>
            <button className="bg-green-500 text-white px-4 py-2 rounded-full hover:opacity-90 text-center">
              Liên hệ
            </button>
            <Link to="/gallery" className="bg-cyan-500 text-white px-4 py-2 rounded-full hover:opacity-90 text-center">
              Thư viện ảnh
            </Link>
          </div>
        </div>
      )}
      
      <div className="w-full h-4 bg-yellow-300 opacity-50 wave"></div>
    </nav>
  );
};

export default Navigation;
